README AltSheets 

changed
* app/app.js lines 1-18 and 51-53
* app/index.html lines 59-61 and 85-87
* app/styles/main.css lines 31-35

added:
* manuals/
* manuals/README.md
* manuals/README-AltSheets.md
* manuals/serverconfig.md
