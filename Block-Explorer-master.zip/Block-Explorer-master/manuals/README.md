# manuals

* [serverconfig](serverconfig.md), e.g. IP and port